# Universal Copy Editor — Free

A practical free copy-editing skill for everyday writing.

## Best for
- typo checking
- grammar and punctuation
- repetition
- readability
- basic logic
- internal consistency
- light rewriting

## Example prompts
- 帮我看看有没有错别字。
- 检查一下这篇稿子顺不顺。
- 找出前后矛盾和重复表达。
- 不要重写，只给修改建议。
- 直接帮我改顺一点。

## Upgrade path

The Pro edition adds:
- external fact-checking
- industry-specific profiles
- style profiles
- 100-point scoring
- publication readiness
- risk checks
- deep QC
- advanced rewrite workflow
## Multilingual

Supports multilingual editing. By default, the skill reviews and rewrites in the same language as the source text. See `references/multilingual-profile.md`.

See `BEFORE-YOU-USE.md` before distribution or public use.

