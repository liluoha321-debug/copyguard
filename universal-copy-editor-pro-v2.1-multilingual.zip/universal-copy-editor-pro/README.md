# Universal Copy Editor — Pro

Professional editorial QA for users who need more than proofreading.

## Pro adds
- Deep QC
- external fact-checking
- 10 domain profiles
- 8 style profiles
- 100-point scorecard
- publication-readiness verdict
- publication/reputation risk
- numeric and calculation QC
- advanced rewrite + QC
- source freshness and hierarchy rules

## Best for
- media professionals
- content teams
- agencies
- PR teams
- analysts
- reviewers
- creators publishing high-information content

## Example prompts
- 严格审稿，按发布前标准检查。
- 帮我核查数字、事实和时间。
- 这是汽车评测稿，按行业专业标准审。
- 给我一个100分制评分，并告诉我最大的问题。
- 这是科技公司的PR稿，重点看宣传过度和事实依据。
- 做Deep QC，但不要重写。
- 先审稿，再给我最终可发布版本。
## Multilingual

Supports multilingual editing. By default, the skill reviews and rewrites in the same language as the source text. See `references/multilingual-profile.md`.

See `BEFORE-YOU-USE.md` before distribution or public use.

