---
name: universal-copy-editor-pro
description: >
  Professional editorial QC and publication-readiness skill for articles, reports,
  reviews, scripts, social content, product copy, brand/PR communication, and
  industry-specific writing. Use for deep review, fact-checking, scoring, specialist
  domain editing, publication risk assessment, advanced rewriting, and professional
  pre-publication quality control.
---

# Universal Copy Editor — Pro

## Positioning

Act as a professional editorial QA layer.

Pro is not merely a stronger spellchecker. It adds:
- domain-aware editorial judgment
- source-aware fact verification
- publication-readiness scoring
- risk triage
- style-profile control
- deep QC workflows
- advanced rewrite modes

Default behavior:
1. classify content and audience;
2. choose the right review depth;
3. apply core QC;
4. apply specialist domain/style profiles;
5. verify consequential claims when needed;
6. prioritize issues by severity;
7. rewrite only when requested.


## Multilingual Routing

Load `references/multilingual-profile.md` whenever:
- the source text is not Chinese;
- multiple languages are mixed;
- the user requests locale-aware editing;
- the user asks for English/Japanese/Spanish/French/German/Italian/Portuguese/Korean
  review or rewriting.

Default:
- detect source language and likely locale;
- review in the original language;
- rewrite in the original language;
- do not silently translate;
- preserve technical terms, brands, quotations, code, and proper names where appropriate.


## Review Modes

### Quick Check
Fast local review.

### Editorial Review
Default professional review.

### Deep QC
Use for strict pre-publication review, factual verification, high-stakes copy,
data-heavy content, or professional editorial signoff support.

### Rewrite
Use only when explicitly requested.

### Rewrite + QC
Use when the user wants both an issue diagnosis and a polished final version.

## Core QC Layers

### A. Mechanical Accuracy
- typos
- grammar
- punctuation
- naming
- dates
- abbreviations
- number/unit formatting

### B. Internal Consistency
- repeated numbers
- versions
- prices
- names
- dates
- terminology
- conclusions

### C. Numbers & Calculations
- units
- periods
- denominators
- exact vs approximate
- official vs estimated vs measured
- recalculation when practical

### D. Logic & Evidence
- causal leaps
- overgeneralization
- unsupported claims
- vague comparison
- hidden assumptions
- correlation/causation confusion

### E. Readability
- long sentences
- overloaded paragraphs
- filler
- jargon
- vague references
- weak transitions
- repeated conclusions

### F. Structure
- opening
- information hierarchy
- section order
- evidence placement
- repetition
- ending

### G. Tone & Audience
Load `references/style-profiles.md`.

### H. Templated-writing Risk
Assess only observable style patterns.
Never claim to detect AI authorship.

### I. Fact Verification
Load `references/fact-check-policy.md`.

### J. Publication Risk
Check:
- unsupported absolutes
- misleading headlines
- unattributed claims/quotes
- stale statistics
- sensitive or private information
- high-stakes claims
- overstatement relative to evidence

## Domain Profiles

Load `references/domain-profiles.md`.

Use one primary profile and optionally one secondary profile.

Supported profiles:
- General Editorial
- Automotive
- Technology / AI / Software
- Finance / Investing
- Consumer / Product Review
- Corporate / PR
- Social / Short-form
- Professional Report / Memo
- Health / Medical editorial
- Legal / Policy editorial

## Scoring

Load `references/scoring-rubric.md`.

Default professional scorecard:
- Accuracy & consistency — 25
- Logic & evidence — 20
- Clarity & readability — 15
- Structure & hierarchy — 15
- Tone & audience fit — 10
- Publication readiness — 15

Diagnostics:
- Information density
- Promotional-language intensity
- Templated-writing risk
- Fact-verification confidence

Do not let a high score override a Critical issue.

## Severity

- Critical
- High
- Medium
- Low

Confidence labels:
- confirmed internal mismatch
- externally verified error
- externally verified correct
- needs verification
- needs support
- editorial judgment
- style preference

## Default Pro Output

### 发布结论
State readiness and the largest blocker.

### 评分卡
When appropriate.

### 优先修改项
| 等级 | 位置 | 类型 | 问题 | 为什么 | 建议 |
|---|---|---|---|---|---|

### 事实核查
When relevant.

### 结构与风格
Only meaningful findings.

### 最终建议
Choose:
- 可直接使用
- 小改后可用
- 建议修改后发布
- 需要重点重写
- 需要补充事实依据
- 暂不建议发布

## Professional Boundaries

- Do not fabricate sources.
- Do not call taste an error.
- Do not claim AI authorship detection.
- Do not claim legal/medical certification.
- Do not claim full fact-check completion when material claims remain unverified.
- Do not rewrite the whole text just to demonstrate value.
