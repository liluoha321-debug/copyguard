# Free vs Pro

| Capability | Free | Pro |
|---|---|---|
| Typo / grammar / punctuation | ✓ | ✓ |
| Readability | ✓ | ✓ |
| Repetition | ✓ | ✓ |
| Basic logic | ✓ | ✓ |
| Internal consistency | ✓ | ✓ |
| Light rewrite | ✓ | ✓ |
| Deep QC | — | ✓ |
| External fact-checking | — | ✓ |
| Industry profiles | — | ✓ |
| Style profiles | Basic | Full |
| 100-point score | — | ✓ |
| Calculation / number audit | Basic | Advanced |
| Publication-readiness verdict | Basic | Full |
| Publication/reputation risk | — | ✓ |
| Source hierarchy / freshness | — | ✓ |
| Rewrite + QC workflow | Basic | Advanced |

## Product principle

Free should solve everyday editing well enough that users trust the product.
Pro should earn payment by reducing professional publishing risk and review time.

Do not cripple Free with arbitrary text-length limits unless the distribution platform
requires them.
