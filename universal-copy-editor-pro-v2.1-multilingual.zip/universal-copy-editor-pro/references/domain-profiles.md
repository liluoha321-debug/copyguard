# Domain Profiles — Pro

## General Editorial
Extra checks:
- opening clarity
- fact vs opinion
- paragraph logic
- repetition
- evidence placement
- conclusion quality

## Automotive
Extra checks:
- model/trim/model-year naming
- dimensions/wheelbase
- battery/powertrain terminology
- charging voltage/platform claims
- power/torque
- acceleration
- range standard
- fuel/electricity consumption units
- ADAS naming and scope
- standard vs optional equipment
- official vs measured experience

Editorial:
- avoid spec-dump prose
- connect parameters to experience
- separate subjective feel from measured data
- flag unsupported “同级领先/全面升级/重新定义”

## Technology / AI / Software
Extra checks:
- model/API/product version
- release date
- announced vs available
- pricing tier
- region/platform compatibility
- benchmark context
- open-source/open-weight/proprietary distinction
- model vs app vs platform vs feature
- demo vs production behavior

## Finance / Investing
Extra checks:
- currency
- as-of date
- fiscal/calendar period
- YoY/QoQ
- percent vs percentage point
- GAAP/non-GAAP
- revenue/profit/cash flow
- market cap/EV
- valuation basis
- stale market data

## Consumer / Product Review
Extra checks:
- model/variant
- MSRP vs current price
- region differences
- configuration
- official vs real-world runtime
- compatibility/warranty
- included vs optional accessories

## Corporate / PR
Extra checks:
- company naming
- executive titles
- event/date naming
- partner names
- quote attribution
- announcement hierarchy
- promotional overreach

## Social / Short-form
Extra checks:
- first-line clarity
- spoken rhythm
- title/body consistency
- CTA naturalness
- sensationalization
- context loss

## Professional Report / Memo
Extra checks:
- decision/question early
- recommendation/evidence separation
- action clarity
- terminology consistency
- executive summary tie-out

## Health / Medical
Editorial-only checks:
- diagnosis/treatment certainty
- absolute safety/effectiveness claims
- study type
- population/context
- dose/unit precision
- source quality/date

## Legal / Policy
Editorial-only checks:
- jurisdiction
- effective date
- law/regulation/policy distinction
- mandatory vs recommended wording
- scope/exceptions
