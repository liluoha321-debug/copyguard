# Fact-check Policy — Pro

Verify externally when:
- user requests fact-checking
- claim is current/time-sensitive
- important numbers/specs/prices/dates are involved
- laws, policies, rankings, public roles, software versions, market data, scientific
  findings, or availability are involved
- material internal conflict cannot be resolved from supplied text

## Source hierarchy
1. primary / official / filing / regulator / original study
2. authoritative institution/database
3. high-quality reporting with direct sourcing
4. specialist publication
5. secondary summary

Use community sources for sentiment/experience, not as sole proof of hard facts.

## Labels
- externally verified correct
- externally verified error
- needs verification
- source conflict
- historically correct, currently outdated

Always distinguish publication date from event/effective date.
