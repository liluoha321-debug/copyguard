# Multilingual Profile — Pro

## Default language routing

Before editing, infer:
- source language
- dominant language when text is mixed
- target output language, if explicitly requested
- locale when materially relevant (e.g. en-US vs en-GB, pt-BR vs pt-PT)

Default behavior:
1. Review in the same language as the source text.
2. Rewrite in the same language as the source text.
3. Keep quotes, code, product names, trademarks, model names, legal names, and technical
   terms in their original form unless correction is required.
4. Do not silently translate.
5. When the user requests a locale, apply locale-appropriate spelling, punctuation,
   date, number, and style conventions where practical.

## Language-aware checks

### Chinese (zh)
Check:
- wrong characters / typos
- punctuation
- sentence flow
- redundancy
- Chinese/English spacing
- register consistency
- formal vs conversational mismatch
- overuse of stock transitions
- terminology consistency

### English (en)
Check:
- spelling
- grammar
- punctuation
- capitalization
- article/preposition usage
- subject-verb agreement
- tense consistency
- parallel structure
- register
- wordiness
- locale conventions (US/UK) when known

### Japanese (ja)
Check:
- particles
- tense/aspect consistency where clear
- polite/plain style consistency
- punctuation
- kana/kanji notation consistency
- redundant expressions
- literal-translation artifacts
- business-formality mismatch

### Spanish (es)
Check:
- spelling/accents
- gender/number agreement
- punctuation
- verb agreement
- register
- regional wording when locale is known

### French (fr)
Check:
- spelling/accents
- gender/number agreement
- article/preposition usage
- punctuation spacing
- register
- Canadian/European distinctions when known

### German (de)
Check:
- capitalization of nouns
- case/agreement where clear
- punctuation
- word order
- compound-word consistency
- formal/informal address consistency

### Italian (it)
Check:
- spelling
- gender/number agreement
- article/preposition usage
- punctuation
- register

### Portuguese (pt)
Check:
- spelling
- agreement
- punctuation
- register
- pt-BR vs pt-PT conventions when known

### Korean (ko)
Check:
- spacing
- particles/endings
- honorific/register consistency
- punctuation
- repeated wording
- terminology consistency

## Mixed-language content

For multilingual content:
- identify the base language;
- keep necessary foreign technical terms;
- flag unnecessary language switching;
- check whether translated terminology is consistent;
- preserve standard industry acronyms;
- do not force localization where the audience expects original terminology.

## Fact-checking across languages

When external verification is needed:
- prefer primary sources in the original jurisdiction/language when available;
- do not assume translated secondary coverage is more authoritative than the original;
- distinguish translation uncertainty from factual uncertainty;
- if a crucial correction depends on nuanced local-language interpretation, label it
  `needs native-language review` when confidence is limited.

## Confidence labels

Use when helpful:
- language check: high confidence
- language check: medium confidence
- needs native-language review
- locale uncertain

## Limitation

This skill is multilingual, not a guarantee of native-editor equivalence in every
language, dialect, legal system, or specialist domain.
High-stakes copy should receive qualified native-language professional review.
