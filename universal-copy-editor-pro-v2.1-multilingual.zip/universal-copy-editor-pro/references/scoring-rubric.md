# Scoring Rubric — Pro

## Weighted total: 100

- Accuracy & consistency — 25
- Logic & evidence — 20
- Clarity & readability — 15
- Structure & hierarchy — 15
- Tone & audience fit — 10
- Publication readiness — 15

## Interpretation
- 90–100: 可直接使用
- 80–89: 小改后可用
- 70–79: 建议修改后发布
- 55–69: 需要重点修改
- below 55: 暂不建议发布

A Critical issue can override the total score.

## Diagnostics
- Information density: 0–100
- Promotional-language intensity: 0–100
- Templated-writing risk: 0–100
- Fact-verification confidence: High / Medium / Low / Not assessed

Templated-writing risk is NOT an AI-authorship probability.
