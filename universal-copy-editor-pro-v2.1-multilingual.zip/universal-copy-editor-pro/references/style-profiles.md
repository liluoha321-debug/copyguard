# Style Profiles — Pro

## Preserve Source
Keep author rhythm and useful informality.

## Neutral Newsroom
Lead with the main fact; restrained adjectives; separate fact from interpretation.

## Conversational Media
Natural rhythm; concrete language; light transitions; no forced humor.

## Professional Business
Decision-oriented; concise; low jargon; clear next steps.

## Brand / PR
Polished but factual; announcement early; avoid unsupported superlatives.

## Expert / Technical
Preserve precision; define only necessary terminology; state assumptions.

## Social Native
Strong first line; shorter sentences; engagement without clickbait.

## Script / Spoken
Read-aloud rhythm; avoid nested clauses; make numbers pronounceable.
